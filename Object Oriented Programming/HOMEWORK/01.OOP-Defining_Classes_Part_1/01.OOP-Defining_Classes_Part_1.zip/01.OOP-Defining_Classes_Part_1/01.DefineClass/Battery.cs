﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _01.DefineClass
{
    // A class to store the battery information
    public class Battery
    {
        // Private fields declaration
        private string batteryModel;
        private double hoursIdle;
        private double hoursTalk;

    }
}
