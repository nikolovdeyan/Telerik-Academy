﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _01.DefineClass
{
    class Program
    {
        static void Main(string[] args)
        {
            // Nothing here yet --> Check the classes GSM, Battery, and Display for problem code.

        }
    }
}
