﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _01.DefineClass
{
    // A class to store the display information
    public class Display
    {
        // Private fields declaration
        private int width;
        private int height;
        private int numberOfColors;
        
    }
}
