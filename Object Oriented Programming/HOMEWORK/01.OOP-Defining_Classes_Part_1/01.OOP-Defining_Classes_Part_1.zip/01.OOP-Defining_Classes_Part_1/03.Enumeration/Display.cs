﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _03.Enumeration
{
    public class Display
    {
        private int width;
        private int height;
        private int numberOfColors;

        public Display(int width, int height, int numberOfColors)
        {
            this.width = width;
            this.height = height;
            this.numberOfColors = numberOfColors;
        }
    }
}
